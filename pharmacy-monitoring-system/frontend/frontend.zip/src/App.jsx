import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import { Link } from "react-router-dom";

export default function App() {
  return (
    <BrowserRouter>
            <nav>
        <Link to="/">Dashboard</Link>
        <Link to="/light">Light Monitoring</Link>
        </nav>
      <Routes>
        <Route path="/" element={<Dashboard />} />
      </Routes>
    </BrowserRouter>
  );
}