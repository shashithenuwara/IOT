import ChatAssistant from "../components/ChatAssistant";
import { useEffect, useState } from "react";
import { subscribeToSensorData } from "../services/firebaseService";
import TrendChart from "../components/TrendChart";
import { getSensorStatus, getStatusColor, generateAlerts } from "../utils/thresholds";
import StatusCard from "../components/StatusCard";

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [anomaly, setAnomaly] = useState(null);

  useEffect(() => {
    subscribeToSensorData(setData);
  }, []);

  useEffect(() => {
    async function checkAnomaly() {
      if (!data?.history || data.history.length < 30) return;

      try {
  const res = await fetch("http://127.0.0.1:5000/anomaly", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ history: data.history }),
  });

  const result = await res.json();
console.log("Anomaly result:", result);
setAnomaly(result);

} catch (error) {
  console.error("Anomaly request failed:", error);
  setAnomaly({
    anomaly: false,
    score: 0,
    message: "AI anomaly service unavailable",
  });
}
    }

    checkAnomaly();
  }, [data]);

  if (!data) {
    return <div style={{ padding: "20px" }}>Loading...</div>;
  }

  const current = data.current;
  const history = data.history;

  const statuses = {
  temperature: getSensorStatus("temperature", current.temperature),
  humidity: getSensorStatus("humidity", current.humidity),
  light: getSensorStatus("light", current.light),
  airQuality: getSensorStatus("airQuality", current.airQuality),
};

function getTrend(data, key) {
  if (data.length < 2) return "stable";

  const first = data[0][key];
  const last = data[data.length - 1][key];

  if (last > first) return "increasing";
  if (last < first) return "decreasing";
  return "stable";
}

const alerts = generateAlerts(current);

  return (
  <div style={{ padding: "20px" }}>
    <h1>Smart Medicine Storage Dashboard</h1>
    <div
  style={{
    background: "linear-gradient(135deg, #2563eb, #3b82f6)",
    color: "white",
    padding: "32px",
    borderRadius: "24px",
    marginBottom: "28px",
    textAlign: "left",
  }}
>
  <p style={{ fontWeight: "bold" }}>SYSTEM STATUS</p>
  <h2 style={{ fontSize: "36px", margin: "8px 0" }}>
    System Overview Dashboard
  </h2>
  <p>Real-time monitoring of pharmacy medicine storage conditions</p>
</div>

    <div
  style={{
    display: "grid",
    gridTemplateColumns: "repeat(4, 1fr)",
    gap: "20px",
    marginBottom: "28px",
  }}
>
  <StatusCard
    title="Temperature Status"
    value={current.temperature}
    unit="°C"
    status={statuses.temperature}
  />
  <StatusCard
    title="Humidity Status"
    value={current.humidity}
    unit="%"
    status={statuses.humidity}
  />
  <StatusCard
    title="Light Level Status"
    value={current.light}
    unit="lux"
    status={statuses.light}
  />
  <StatusCard
    title="Air Quality Status"
    value={current.airQuality}
    unit="ppm"
    status={statuses.airQuality}
  />
</div>

{anomaly && (
  <div
    style={{
      padding: "18px",
      borderRadius: "14px",
      marginBottom: "24px",
      background: anomaly.anomaly ? "#7f1d1d" : "#064e3b",
      color: "white",
    }}
  >
    <h2>AI Anomaly Detection</h2>
    <p>{anomaly.message}</p>
    <p>Score: {anomaly.score}</p>
  </div>
)}

<h2>Recent Alerts</h2>

<div style={{ marginBottom: "24px" }}>
  {alerts.length === 0 ? (
    <p>All sensor readings are currently within safe limits.</p>
  ) : (
    alerts.map((alert) => (
      <div
        key={alert.key}
        style={{
          padding: "14px",
          marginBottom: "10px",
          borderRadius: "10px",
          background: "#1f2937",
          borderLeft: `6px solid ${getStatusColor(alert.status)}`,
        }}
      >
        <strong>{alert.status}: {alert.label}</strong>
        <p>
          {alert.message}. Current value: {alert.value} {alert.unit}
        </p>
      </div>
    ))
  )}
</div>

    <h2>Environmental Trends</h2>

<div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
  <TrendChart data={history} dataKey="temperature" color="red" />
  <TrendChart data={history} dataKey="humidity" color="blue" />
  <TrendChart data={history} dataKey="light" color="orange" />
  <TrendChart data={history} dataKey="airQuality" color="green" />
</div>
    <ChatAssistant data={{ current, statuses, alerts, anomaly }} />
  </div>
);
}