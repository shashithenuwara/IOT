import { getStatusColor } from "../utils/thresholds";

export default function StatusCard({ title, value, unit, status }) {
  return (
    <div
      style={{
        padding: "22px",
        borderRadius: "18px",
        background: "#ecfdf5",
        border: `2px solid ${getStatusColor(status)}`,
        color: "#111827",
        boxShadow: "0 8px 20px rgba(0,0,0,0.12)",
      }}
    >
      <h3>{title}</h3>
      <p style={{ fontSize: "34px", fontWeight: "bold", margin: "12px 0" }}>
        {value} {unit}
      </p>
      <span
        style={{
          background: getStatusColor(status),
          color: "white",
          padding: "7px 14px",
          borderRadius: "999px",
          fontWeight: "bold",
        }}
      >
        {status}
      </span>
    </div>
  );
}