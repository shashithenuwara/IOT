import { useEffect, useState } from "react";
import { subscribeToSensorData } from "../services/firebaseService";
import ChartCard from "../components/ChartCard";
import StatusCard from "../components/StatusCard";
import { getSensorStatus } from "../utils/thresholds";

export default function AirQuality() {
  const [data, setData] = useState(null);

  useEffect(() => {
    subscribeToSensorData(setData);
  }, []);

  if (!data) return <p>Loading...</p>;

  const current = data.current;
  const history = data.history;
  const status = getSensorStatus("airQuality", current.airQuality);

  return (
    <>
      <h1>Air Quality Monitoring</h1>
      <p style={{ color: "#64748b", marginBottom: "24px" }}>
        Detailed analysis of storage air quality conditions.
      </p>

      <div style={{ maxWidth: "320px", marginBottom: "28px" }}>
        <StatusCard
          title="Current Air Quality"
          value={current.airQuality}
          unit="AQI"
          status={status}
        />
      </div>

      <ChartCard
        title="Air Quality Trend"
        data={history}
        dataKey="airQuality"
        color="green"
      />

      <div
        style={{
          background: "white",
          padding: "24px",
          borderRadius: "24px",
          marginTop: "28px",
          boxShadow: "0 12px 30px rgba(15,23,42,0.08)",
        }}
      >
        <h2>Decision Support</h2>
        <p>
          Safe pharmacy air quality range is typically maintained between 0 and 50 AQI.
          If readings exceed this range, inspect air filtration systems and storage ventilation.
        </p>
      </div>
    </>
  );
}