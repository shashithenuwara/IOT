import { useEffect, useState } from "react";
import { subscribeToSensorData } from "../services/firebaseService";
import ChartCard from "../components/ChartCard";
import StatusCard from "../components/StatusCard";
import { getSensorStatus } from "../utils/thresholds";

export default function Temperature() {
  const [data, setData] = useState(null);

  useEffect(() => {
    subscribeToSensorData(setData);
  }, []);

  if (!data) return <p>Loading...</p>;

  const current = data.current;
  const history = data.history;
  const status = getSensorStatus("temperature", current.temperature);

  return (
    <>
      <h1>Temperature Monitoring</h1>
      <p style={{ color: "#64748b", marginBottom: "24px" }}>
        Detailed analysis of storage temperature conditions.
      </p>

      <div style={{ maxWidth: "320px", marginBottom: "28px" }}>
        <StatusCard
          title="Current Temperature"
          value={current.temperature}
          unit="°C"
          status={status}
        />
      </div>

      <ChartCard
        title="Temperature Trend"
        data={history}
        dataKey="temperature"
        color="red"
      />

      <div
        style={{
          background: "white",
          padding: "24px",
          borderRadius: "24px",
          marginTop: "28px",
          boxShadow: "0 12px 30px rgba(15,23,42,0.08)",
        }}
      >
        <h2>Decision Support</h2>
        <p>
          Safe pharmacy temperature range is typically maintained between 15°C and 25°C.
          If readings exceed this range, inspect cooling systems and storage ventilation.
        </p>
      </div>
    </>
  );
}