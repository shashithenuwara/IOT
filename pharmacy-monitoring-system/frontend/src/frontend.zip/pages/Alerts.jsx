import { useEffect, useState } from "react";
import { subscribeToSensorData } from "../services/firebaseService";
import { generateAlerts, getStatusColor } from "../utils/thresholds";

export default function Alerts() {
  const [data, setData] = useState(null);

  useEffect(() => {
    subscribeToSensorData(setData);
  }, []);

  if (!data) return <p>Loading...</p>;

  const alerts = generateAlerts(data.current);

  return (
    <>
      <h1>Alert Overview</h1>
      <p style={{ color: "#64748b", marginBottom: "24px" }}>
        Current unsafe or warning conditions detected from live sensor readings.
      </p>

      <div
        style={{
          background: "white",
          borderRadius: "24px",
          padding: "24px",
          boxShadow: "0 12px 30px rgba(15,23,42,0.08)",
        }}
      >
        {alerts.length === 0 ? (
          <p>All environmental conditions are currently safe.</p>
        ) : (
          alerts.map((alert) => (
            <div
              key={alert.key}
              style={{
                padding: "18px",
                borderRadius: "18px",
                background: "#f8fafc",
                borderLeft: `6px solid ${getStatusColor(alert.status)}`,
                marginBottom: "14px",
              }}
            >
              <h3>
                {alert.status}: {alert.label}
              </h3>
              <p style={{ color: "#475569" }}>
                {alert.message}. Current value: {alert.value} {alert.unit}
              </p>
            </div>
          ))
        )}
      </div>
    </>
  );
}