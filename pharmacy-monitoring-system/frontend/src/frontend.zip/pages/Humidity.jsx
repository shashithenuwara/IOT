import { useEffect, useState } from "react";
import { subscribeToSensorData } from "../services/firebaseService";
import ChartCard from "../components/ChartCard";
import StatusCard from "../components/StatusCard";
import { getSensorStatus } from "../utils/thresholds";

export default function Humidity() {
  const [data, setData] = useState(null);

  useEffect(() => {
    subscribeToSensorData(setData);
  }, []);

  if (!data) return <p>Loading...</p>;

  const current = data.current;
  const history = data.history;
  const status = getSensorStatus("humidity", current.humidity);

  return (
    <>
      <h1>Humidity Monitoring</h1>
      <p style={{ color: "#64748b", marginBottom: "24px" }}>
        Detailed analysis of storage humidity conditions.
      </p>

      <div style={{ maxWidth: "320px", marginBottom: "28px" }}>
        <StatusCard
          title="Current Humidity"
          value={current.humidity}
          unit="%"
          status={status}
        />
      </div>

      <ChartCard
        title="Humidity Trend"
        data={history}
        dataKey="humidity"
        color="blue"
      />

      <div
        style={{
          background: "white",
          padding: "24px",
          borderRadius: "24px",
          marginTop: "28px",
          boxShadow: "0 12px 30px rgba(15,23,42,0.08)",
        }}
      >
        <h2>Decision Support</h2>
        <p>
          Safe pharmacy humidity range is typically maintained between 40% and 60%.
          If readings exceed this range, inspect dehumidification systems and storage ventilation.
        </p>
      </div>
    </>
  );
}