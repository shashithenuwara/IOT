import { useEffect, useState } from "react";
import { subscribeToSensorData } from "../services/firebaseService";
import ChartCard from "../components/ChartCard";
import StatusCard from "../components/StatusCard";
import { getSensorStatus } from "../utils/thresholds";

export default function Light() {
  const [data, setData] = useState(null);

  useEffect(() => {
    subscribeToSensorData(setData);
  }, []);

  if (!data) return <p>Loading...</p>;

  const current = data.current;
  const history = data.history;
  const status = getSensorStatus("light", current.light);

  return (
    <>
      <h1>Light Monitoring</h1>
      <p style={{ color: "#64748b", marginBottom: "24px" }}>
        Detailed analysis of storage light conditions.
      </p>

      <div style={{ maxWidth: "320px", marginBottom: "28px" }}>
        <StatusCard
          title="Current Light"
          value={current.light}
          unit="lux"
          status={status}
        />
      </div>

      <ChartCard
        title="Light Trend"
        data={history}
        dataKey="light"
        color="yellow"
      />

      <div
        style={{
          background: "white",
          padding: "24px",
          borderRadius: "24px",
          marginTop: "28px",
          boxShadow: "0 12px 30px rgba(15,23,42,0.08)",
        }}
      >
        <h2>Decision Support</h2>
        <p>
          Safe pharmacy light range is typically maintained between 150 lux and 300 lux.
          If readings exceed this range, adjust lighting systems and storage ventilation.
        </p>
      </div>
    </>
  );
}