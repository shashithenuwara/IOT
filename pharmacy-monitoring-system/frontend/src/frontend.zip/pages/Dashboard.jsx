import ChatAssistant from "../components/ChatAssistant";
import { useEffect, useState } from "react";
import { subscribeToSensorData } from "../services/firebaseService";
import TrendChart from "../components/TrendChart";
import {
  getSensorStatus,
  getStatusColor,
  generateAlerts,
} from "../utils/thresholds";
import StatusCard from "../components/StatusCard";

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [anomaly, setAnomaly] = useState(null);

  useEffect(() => {
    subscribeToSensorData(setData);
  }, []);

  useEffect(() => {
    async function checkAnomaly() {
      if (!data?.history || data.history.length < 30) return;

      try {
        const res = await fetch("http://127.0.0.1:5000/anomaly", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ history: data.history }),
        });

        const result = await res.json();
        setAnomaly(result);
      } catch (error) {
        console.error("Anomaly request failed:", error);
        setAnomaly({
          anomaly: false,
          score: 0,
          message: "AI anomaly service unavailable",
        });
      }
    }

    checkAnomaly();
  }, [data]);

  if (!data) {
    return <div style={{ padding: "28px" }}>Loading...</div>;
  }

  const current = data.current;
  const history = data.history;

  const statuses = {
    temperature: getSensorStatus("temperature", current.temperature),
    humidity: getSensorStatus("humidity", current.humidity),
    light: getSensorStatus("light", current.light),
    airQuality: getSensorStatus("airQuality", current.airQuality),
  };

  const alerts = generateAlerts(current);

  const healthScore = Math.round(
    (Object.values(statuses).filter((s) => s === "Safe").length /
      Object.values(statuses).length) *
      100
  );

  const chartCards = [
    ["Temperature Trend", "temperature", "#ef4444"],
    ["Humidity Trend", "humidity", "#2563eb"],
    ["Light Trend", "light", "#f59e0b"],
    ["Air Quality Trend", "airQuality", "#16a34a"],
  ];

  return (
    <div
  style={{
    width: "100%",
    minHeight: "calc(100vh - 72px)",
    background: "#f1f5f9",
    padding: "36px 48px 220px",
    color: "#0f172a",
    boxSizing: "border-box",
  }}
>
      <section
        style={{
          background: "linear-gradient(135deg, #2563eb, #1d4ed8)",
          color: "white",
          padding: "36px",
          borderRadius: "28px",
          marginBottom: "28px",
          boxShadow: "0 18px 36px rgba(37,99,235,0.25)",
          display: "flex",
          justifyContent: "space-between",
          gap: "24px",
          alignItems: "center",
        }}
      >
        <div>
          <p style={{ fontWeight: "800", letterSpacing: "1px" }}>
            SYSTEM STATUS
          </p>
          <h1 style={{ fontSize: "42px", margin: "8px 0", fontWeight: "800" }}>
            System Overview Dashboard
          </h1>
          <p style={{ fontSize: "16px", opacity: 0.9 }}>
            Real-time monitoring of pharmacy medicine storage conditions
          </p>
        </div>

        <div
          style={{
            background: "rgba(255,255,255,0.16)",
            border: "1px solid rgba(255,255,255,0.22)",
            borderRadius: "22px",
            padding: "22px 28px",
            minWidth: "150px",
            textAlign: "center",
          }}
        >
          <p style={{ margin: 0, opacity: 0.9 }}>System Health</p>
          <h2 style={{ fontSize: "34px", margin: "6px 0 0" }}>
            {healthScore}%
          </h2>
        </div>
      </section>

      <section
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
          gap: "20px",
          marginBottom: "28px",
        }}
      >
        <StatusCard
          title="Temperature Status"
          value={current.temperature}
          unit="°C"
          status={statuses.temperature}
        />
        <StatusCard
          title="Humidity Status"
          value={current.humidity}
          unit="%"
          status={statuses.humidity}
        />
        <StatusCard
          title="Light Level Status"
          value={current.light}
          unit="lux"
          status={statuses.light}
        />
        <StatusCard
          title="Air Quality Status"
          value={current.airQuality}
          unit="ppm"
          status={statuses.airQuality}
        />
      </section>

      {anomaly && (
        <section
          style={{
            background: anomaly.anomaly ? "#7f1d1d" : "#065f46",
            color: "white",
            padding: "24px",
            borderRadius: "22px",
            marginBottom: "28px",
            boxShadow: "0 12px 30px rgba(15,23,42,0.12)",
          }}
        >
          <h2 style={{ marginTop: 0 }}>AI Anomaly Detection</h2>
          <p style={{ fontSize: "17px" }}>{anomaly.message}</p>
          <p style={{ marginBottom: 0 }}>
            Score: {Number(anomaly.score).toFixed(4)}
          </p>
        </section>
      )}

      <section
        style={{
          background: "white",
          padding: "24px",
          borderRadius: "24px",
          boxShadow: "0 12px 30px rgba(15,23,42,0.08)",
          marginBottom: "28px",
        }}
      >
        <h2 style={{ marginTop: 0 }}>Recent Alerts</h2>

        {alerts.length === 0 ? (
          <p style={{ color: "#475569" }}>
            All sensor readings are currently within safe limits.
          </p>
        ) : (
          alerts.map((alert) => (
            <div
              key={alert.key}
              style={{
                padding: "16px",
                marginTop: "12px",
                borderRadius: "16px",
                background: "#f8fafc",
                borderLeft: `6px solid ${getStatusColor(alert.status)}`,
              }}
            >
              <strong>
                {alert.status}: {alert.label}
              </strong>
              <p style={{ margin: "6px 0 0", color: "#475569" }}>
                {alert.message}. Current value: {alert.value} {alert.unit}
              </p>
            </div>
          ))
        )}
      </section>

      <section>
        <h2 style={{ margin: "0 0 16px" }}>Environmental Trends</h2>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "22px",
          }}
        >
          {chartCards.map(([title, key, color]) => (
            <div
              key={key}
              style={{
                background: "white",
                padding: "24px",
                borderRadius: "24px",
                boxShadow: "0 12px 30px rgba(15,23,42,0.08)",
              }}
            >
              <h3 style={{ marginTop: 0 }}>{title}</h3>
              <TrendChart data={history} dataKey={key} color={color} />
            </div>
          ))}
        </div>
      </section>

      <div
  style={{
    position: "fixed",
    right: "24px",
    bottom: "24px",
    width: "320px",
    maxHeight: "360px",
    overflowY: "auto",
    background: "#1e293b",
    borderRadius: "22px",
    padding: "16px",
    color: "white",
    boxShadow: "0 24px 60px rgba(0,0,0,0.35)",
    border: "1px solid rgba(255,255,255,0.08)",
    zIndex: 1000,
  }}
>
  <ChatAssistant data={{ current, statuses, alerts, anomaly }} />
</div>
    </div>
  );
}