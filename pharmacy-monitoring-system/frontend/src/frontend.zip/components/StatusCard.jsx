import { getStatusColor } from "../utils/thresholds";

export default function StatusCard({ title, value, unit, status }) {
  const color = getStatusColor(status);

  return (
    <div
      style={{
        background: "white",
        borderRadius: "22px",
        padding: "24px",
        boxShadow: "0 12px 30px rgba(15,23,42,0.08)",
        borderTop: `6px solid ${color}`,
        transition: "all 0.25s ease",
        cursor: "pointer",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = "translateY(-6px)";
        e.currentTarget.style.boxShadow =
          "0 20px 45px rgba(15,23,42,0.12)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.boxShadow =
          "0 12px 30px rgba(15,23,42,0.08)";
      }}
    >
      {/* Title */}
      <p
        style={{
          color: "#64748b",
          fontWeight: "600",
          fontSize: "14px",
          letterSpacing: "0.3px",
        }}
      >
        {title}
      </p>

      {/* Value */}
      <h2
        style={{
          fontSize: "38px",
          margin: "10px 0",
          color: "#0f172a",
          fontWeight: "800",
        }}
      >
        {Number(value).toFixed(2)}{" "}
        <span style={{ fontSize: "16px", fontWeight: "500" }}>{unit}</span>
      </h2>

      {/* Status badge */}
      <span
        style={{
          background: color,
          color: "white",
          padding: "6px 14px",
          borderRadius: "999px",
          fontSize: "12px",
          fontWeight: "700",
          letterSpacing: "0.4px",
          boxShadow: `0 4px 12px ${color}55`,
        }}
      >
        {status}
      </span>
    </div>
  );
}