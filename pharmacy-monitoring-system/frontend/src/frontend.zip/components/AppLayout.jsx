import { Link } from "react-router-dom";

export default function AppLayout({ children }) {
  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#eef3f8",
        color: "#0f172a",
      }}
    >
    <nav
    style={{
    height: "72px",
    background: "rgba(255,255,255,0.85)",
    backdropFilter: "blur(12px)",
    display: "flex",
    alignItems: "center",
    padding: "0 42px",
    boxShadow: "0 2px 20px rgba(15,23,42,0.06)",
    position: "sticky",
    top: 0,
    zIndex: 100,
  }}
>
        <div style={{ fontSize: "22px", fontWeight: "800", marginRight: "auto" }}>
          Smart Medicine Storage
        </div>

        {[
          ["/", "Dashboard"],
          ["/temperature", "Temperature"],
          ["/humidity", "Humidity"],
          ["/light", "Light"],
          ["/air-quality", "Air Quality"],
          ["/alerts", "Alerts"],
        ].map(([to, label]) => (
          <Link
            key={to}
            to={to}
            style={{
              marginLeft: "22px",
              color: "#334155",
              textDecoration: "none",
              fontWeight: "600",
            }}
          >
            {label}
          </Link>
        ))}
      </nav>

      <main
  style={{
    width: "100%",
    minHeight: "calc(100vh - 70px)",
    background: "#f1f5f9",
  }}
>
  {children}
</main>
    </div>
  );
}